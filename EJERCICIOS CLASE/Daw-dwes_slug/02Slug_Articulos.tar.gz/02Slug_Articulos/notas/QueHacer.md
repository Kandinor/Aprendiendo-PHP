# s3 Mayo

## DWES - DAW

Desarrolla una aplicación web en PHP que permita a los usuarios ver y gestionar una lista de artículos. 
Cada artículo tendrá un título, un contenido y una fecha de publicación. 
Los artículos se almacenarán en una base de datos MySQL. 
Además, la aplicación deberá soportar URLs amigables utilizando la reescritura de URLs de Apache.