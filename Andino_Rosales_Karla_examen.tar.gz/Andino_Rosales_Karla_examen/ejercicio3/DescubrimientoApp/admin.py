from django.contrib import admin
from .models import AreaConocimiento, Descubrimiento

admin.site.register(AreaConocimiento)
admin.site.register(Descubrimiento)
